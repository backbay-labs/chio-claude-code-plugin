from pathlib import Path
import gzip,hashlib,json,os,signal,subprocess,tarfile,time
repo=Path('/Users/connor/Medica/backbay/standalone/chio-claude-code-plugin/.worktrees/required-agent-integrations-20260909')
out=Path('/tmp/chio-claude-supervisor-local-20260910');out.mkdir(mode=0o700,exist_ok=False)
temporary=out/'isolated-tmp';temporary.mkdir(mode=0o700)
source=subprocess.check_output(['git','rev-parse','HEAD'],cwd=repo,text=True).strip();assert source=='00a0ad130cf13fbe434ab08616fe2f2483187c77'
assert not subprocess.check_output(['git','status','--porcelain'],cwd=repo,text=True).strip()
paths=['test/restricted.test.mjs','scripts/host-supervisor.mjs','scripts/restricted.mjs','scripts/sandbox.mjs','scripts/model-relay.mjs']
hashes={p:hashlib.sha256((repo/p).read_bytes()).hexdigest() for p in paths}
archive=Path('/Users/connor/.local/share/chio-required-candidates/claude-auth-docs-successor-20260910/chio-claude-code-plugin-0.3.1-rc.1.tgz')
assert hashlib.sha256(archive.read_bytes()).hexdigest()=='1258385647d228ebeed32662091ed721aeda3b60450cabae480ca0d4292fbe0a'
with tarfile.open(archive) as package:
 archive_supervisor=package.extractfile('package/scripts/host-supervisor.mjs').read()
 assert archive_supervisor==(repo/'scripts/host-supervisor.mjs').read_bytes()
command=['node','--test','--test-reporter=tap','--test-name-pattern=^trusted host supervisor stops its process group when the parent lifeline closes$','test/restricted.test.mjs']
env=os.environ.copy();env['TMPDIR']=str(temporary)
start=time.monotonic();child=subprocess.Popen(command,cwd=repo,env=env,stdout=subprocess.PIPE,stderr=subprocess.PIPE,text=True,start_new_session=True)
timed_out=False
try:stdout,stderr=child.communicate(timeout=20)
except subprocess.TimeoutExpired:
 timed_out=True;os.killpg(child.pid,signal.SIGTERM);stdout,stderr=child.communicate(timeout=10)
(out/'stdout.tap').write_text(stdout);(out/'stderr.txt').write_text(stderr)
source_after=subprocess.check_output(['git','rev-parse','HEAD'],cwd=repo,text=True).strip();hashes_after={p:hashlib.sha256((repo/p).read_bytes()).hexdigest() for p in paths}
record={'source':source,'sourceAfter':source_after,'command':command,'cwd':str(repo),'privateTmpdir':str(temporary),'exitCode':child.returncode,'timedOut':timed_out,'elapsedSeconds':time.monotonic()-start,'platform':subprocess.check_output(['node','-p','process.platform'],text=True).strip(),'nodeVersion':subprocess.check_output(['node','--version'],text=True).strip(),'operatingSystem':subprocess.check_output(['sw_vers'],text=True),'sourceHashes':hashes,'sourceHashesAfter':hashes_after,'sourceUnchanged':source==source_after and hashes==hashes_after,'archiveSha256':hashlib.sha256(archive.read_bytes()).hexdigest(),'archiveSupervisorEqualsCurrentSource':True,'temporaryChildrenAfter':list(map(str,temporary.iterdir())),'testName':'trusted host supervisor stops its process group when the parent lifeline closes','upstreamSkipCondition':'process.platform !== "darwin"','fixtureDescription':'Real macOS sandbox-exec launches disposable Node readiness/timer process. Closing private supervisor FD3 must stop child group and exit143. No Claude host/model/auth/profile is launched or mutated.','qualification':'Exact current-source macOS component test execution; not independent full native-host I01-I08 acceptance.'}
record['passed']=child.returncode==0 and not timed_out and '# pass 1' in stdout and '# skipped 0' in stdout and record['sourceUnchanged'] and not record['temporaryChildrenAfter']
(out/'result.json').write_text(json.dumps(record,indent=2)+'\n')
print(json.dumps({k:v for k,v in record.items() if k not in ['sourceHashes','sourceHashesAfter']}));print(stdout);raise SystemExit(0 if record['passed'] else 1)
