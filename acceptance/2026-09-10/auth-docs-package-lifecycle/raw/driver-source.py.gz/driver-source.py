from pathlib import Path
import hashlib,importlib.util,json,os,subprocess,time
repo=Path('/Users/connor/Medica/backbay/standalone/chio-claude-code-plugin/.worktrees/required-agent-integrations-20260909')
source=repo/'scripts/acceptance/native-subscription.py'
spec=importlib.util.spec_from_file_location('native',source);module=importlib.util.module_from_spec(spec);spec.loader.exec_module(module)
out=Path('/tmp/chio-claude-package-lifecycle-125838-20260910');out.mkdir(mode=0o700)
(out/'driver-source.py').write_bytes(Path(__file__).read_bytes());(out/'native-driver-source.py').write_bytes(source.read_bytes())
old=Path('/tmp/chio-claude-native-outcomes-package-r5-20260909/chio-claude-code-plugin-0.3.0.tgz');oldhash='0dd0d906fc34b3ac7d09e3b7f6cdee9f13f511731b25ec761feca7172c9b1158'
new=Path('/Users/connor/.local/share/chio-required-candidates/claude-auth-docs-successor-20260910/chio-claude-code-plugin-0.3.1-rc.1.tgz');newhash='1258385647d228ebeed32662091ed721aeda3b60450cabae480ca0d4292fbe0a'
assert module.digest(old)==oldhash and module.digest(new)==newhash
consumer=out/'consumer';package=consumer/'node_modules/@chio/claude-code-plugin';canary=out/'operator-state-canary.txt';canary.write_text('non-authoritative package lifecycle canary\n');canaryhash=module.digest(canary)
env={k:v for k,v in os.environ.items() if not k.upper().startswith(('NPM_CONFIG_','NPM_TOKEN','NODE_AUTH_TOKEN','ANTHROPIC_','CLAUDE_CODE_OAUTH_TOKEN')) and k!='NODE_OPTIONS'}
config=out/'empty.npmrc';config.write_text('');env['NPM_CONFIG_USERCONFIG']=str(config)
records=[]
def run(label,cmd):
 start=time.monotonic();p=subprocess.run(cmd,capture_output=True,text=True,cwd=out,env=env,timeout=120)
 (out/(label+'.stdout')).write_text(p.stdout);(out/(label+'.stderr')).write_text(p.stderr)
 records.append({'case':label,'command':cmd,'exitCode':p.returncode,'elapsedSeconds':time.monotonic()-start});(out/'commands.json').write_text(json.dumps(records,indent=2)+'\n');return p
try:
 for label,archive,sha in [('install-prior',old,oldhash),('upgrade',new,newhash)]:
  cache=out/(label+'-empty-cache');assert not cache.exists()
  p=run(label,['npm','install','--prefix',str(consumer),'--cache',str(cache),'--offline','--ignore-scripts','--no-audit','--no-fund',str(archive)]);assert p.returncode==0
  ids=module.verify_installed_archive(archive,sha,package);(out/(label+'-installed-files.json')).write_text(json.dumps(ids,indent=2)+'\n');assert module.digest(canary)==canaryhash
 p=run('remove',['npm','uninstall','--prefix',str(consumer),'--cache',str(out/'remove-empty-cache'),'--offline','--ignore-scripts','--no-audit','--no-fund','@chio/claude-code-plugin']);assert p.returncode==0 and not package.exists()
 p=run('removed-entrypoint',['node',str(package/'scripts/restricted.mjs')]);assert p.returncode!=0 and 'MODULE_NOT_FOUND' in p.stderr;assert module.digest(canary)==canaryhash
 result={'passed':True,'claim':'Binary-independent offline package installation, upgrade and removal only; no native/kernel/journal acceptance','previousArchiveSha256':oldhash,'archiveSha256':newhash,'oldFilesVerified':len(json.loads((out/'install-prior-installed-files.json').read_text())),'newFilesVerified':len(ids),'canaryUnchanged':True,'removedEntrypointFails':True,'nativeDriverSha256':module.digest(source)}
except Exception as error:result={'passed':False,'error':str(error)}
(out/'result.json').write_text(json.dumps(result,indent=2)+'\n');print(json.dumps(result));raise SystemExit(0 if result['passed'] else 1)
